package org.example.old;

import org.example.main.factory.Quadcopter;

public class OldQuadcopter implements Quadcopter {
    @Override
    public String fly() {
        return "Old quadcopter fly";
    }
}
