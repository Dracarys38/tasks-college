package org.example.old;

import org.example.main.factory.AbstractFactory;
import org.example.main.factory.Helicopter;
import org.example.main.factory.Plane;
import org.example.main.factory.Quadcopter;

public class OldFactory implements AbstractFactory {
    @Override
    public Helicopter createHalicopter() {
        return new OldHelicopter();
    }

    @Override
    public Quadcopter createQuadcopter() {
        return new OldQuadcopter();
    }

    @Override
    public Plane createPlane() {
        return new OldPlane();
    }
}
