package org.example.old;

import org.example.main.factory.Plane;

public class OldPlane implements Plane {
    @Override
    public String fly() {
        return "Old plane fly";
    }
}
