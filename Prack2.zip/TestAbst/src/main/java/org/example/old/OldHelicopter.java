package org.example.old;

import org.example.main.factory.Helicopter;

public class OldHelicopter implements Helicopter {
    @Override
    public String fly() {
        return "Old helicopter fly";
    }
}
