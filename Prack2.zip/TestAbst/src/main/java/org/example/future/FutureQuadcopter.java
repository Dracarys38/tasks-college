package org.example.future;

import org.example.main.factory.Quadcopter;

public class FutureQuadcopter implements Quadcopter {
    @Override
    public String fly() {
        return "Future quadcopter fly";
    }
}
