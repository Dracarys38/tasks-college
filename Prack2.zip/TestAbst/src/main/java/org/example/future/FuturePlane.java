package org.example.future;

import org.example.main.factory.Plane;

public class FuturePlane implements Plane {
    @Override
    public String fly() {
        return "Future plane fly";
    }
}
