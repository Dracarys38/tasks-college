package org.example.future;

import org.example.main.factory.AbstractFactory;
import org.example.main.factory.Helicopter;
import org.example.main.factory.Plane;
import org.example.main.factory.Quadcopter;

public class FutureFactory implements AbstractFactory {
    @Override
    public Helicopter createHalicopter() {
        return new FutureHelicopter();
    }

    @Override
    public Quadcopter createQuadcopter() {
        return new FutureQuadcopter();
    }

    @Override
    public Plane createPlane() {
        return new FuturePlane();
    }
}
