package org.example.future;

import org.example.main.factory.Helicopter;

public class FutureHelicopter implements Helicopter {
    @Override
    public String fly() {
        return "Future helicopter fly";
    }
}
