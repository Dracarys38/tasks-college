package org.example.main.factory;

import org.example.future.FutureFactory;
import org.example.modern.ModernFactory;
import org.example.old.OldFactory;

public class ControllerFactory {
    public static AbstractFactory getFactory(Style style){
        AbstractFactory factory = null;
        switch (style){
            case MODERN -> {
                factory = new ModernFactory();
            }
            case OLD ->
            {
                factory = new OldFactory();
            }
            case FUTURE -> {
                factory = new FutureFactory();
            }
        }
        return factory;
    }
}

