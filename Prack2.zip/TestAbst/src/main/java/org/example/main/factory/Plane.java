package org.example.main.factory;

public interface Plane {
    String fly();
}
