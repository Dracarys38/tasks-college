package org.example.main.factory;

public interface AbstractFactory {
    Helicopter createHalicopter();
    Quadcopter createQuadcopter();
    Plane createPlane();
}
