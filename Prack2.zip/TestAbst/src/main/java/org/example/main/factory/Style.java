package org.example.main.factory;

public enum Style {
    MODERN,
    OLD,
    FUTURE
}
