package org.example.main.factory;

public interface Quadcopter {
    String fly();
}
