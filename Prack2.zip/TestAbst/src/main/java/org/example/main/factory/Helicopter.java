package org.example.main.factory;

public interface Helicopter {
    String fly();
}
