package org.example.modern;

import org.example.main.factory.Helicopter;

import java.awt.*;

public class ModernHelicopter implements Helicopter {
    @Override
    public String fly() {
        return "Modern helicopter fly";
    }
}
