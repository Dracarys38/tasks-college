package org.example.modern;

import org.example.main.factory.AbstractFactory;
import org.example.main.factory.Helicopter;
import org.example.main.factory.Plane;
import org.example.main.factory.Quadcopter;

public class ModernFactory implements AbstractFactory {
    @Override
    public Helicopter createHalicopter() {
        return new ModernHelicopter();
    }

    @Override
    public Quadcopter createQuadcopter() {
        return new ModernQuadcopter();
    }

    @Override
    public Plane createPlane() {
        return new ModernPlane();
    }
}
