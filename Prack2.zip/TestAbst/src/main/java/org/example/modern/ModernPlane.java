package org.example.modern;

import org.example.main.factory.Plane;

public class ModernPlane implements Plane {
    @Override
    public String fly() {
        return "Modern plane fly";
    }
}
