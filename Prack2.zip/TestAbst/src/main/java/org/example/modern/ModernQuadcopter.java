package org.example.modern;

import org.example.main.factory.Quadcopter;

public class ModernQuadcopter implements Quadcopter {
    @Override
    public String fly() {
        return "Modern quadcopter fly";
    }
}
