namespace Singltone
{
    public partial class Form1 : Form
    {
        private Singleton singleton = Singleton.GetInstance();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            singleton.Write(e.KeyCode);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<string> list = singleton.Read();
            listBox1.Items.Clear();
            foreach(string s in list)
            {
                listBox1.Items.Add(s);
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}